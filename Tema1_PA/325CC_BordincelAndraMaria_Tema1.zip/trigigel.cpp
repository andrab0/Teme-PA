#include <bits/stdc++.h>
#include <iostream>
#include <fstream>


using namespace std;

fstream f1("trigigel.in", ios::in),
        f2("trigigel.out", ios::out);

using namespace std;

int main() {
    int N;

    // am citit doar N-ul .. :((
    f1 >> N;

    f2.close();
    f1.close();
    return 0;
}

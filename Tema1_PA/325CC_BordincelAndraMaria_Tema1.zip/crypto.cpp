#include <bits/stdc++.h>

#include <iostream>
#include <fstream>
#include <functional>
#include <algorithm>

using namespace std;

fstream f1("crypto.in", ios::in),
        f2("crypto.out", ios::out);

struct cryptoMoneda {
    long P;
    long U;
};

bool comparator(cryptoMoneda a, cryptoMoneda b) {
    if (a.P == b.P)
        return (a.U < b.U);
    return (a.P < b.P);
}

long calculCostUpgrade(cryptoMoneda *v, long dim, long B, long *costuri) {
    long totalCost = 0;
    long i = 0;
    long maxCrypto = v[0].P;

    while (i < dim) {
        if (i == dim - 1) {
            long final_update = (B - totalCost) / costuri[dim - 1];
            maxCrypto += final_update;
            return maxCrypto;
        }

        // Calculez diferenta de putere dintre urmatorul calculator
        // si calculatorul actual:
        long dif = v[i + 1].P - maxCrypto;

        // Daca calculatoarele au aceeasi putere, trec mai departe.
        // Daca nu sunt egale, cresc costul total:
        if (dif != 0) {
            totalCost = totalCost + dif * costuri[i];
        } else {
            ++i;
            continue;
        }

        // Verific daca update-ul actual consuma toti banii ramasi.
        // Daca banii sunt suficienti pentru update, incrementez numarul
        // de cripto ce pot fi minate, altfel termin calculul:
        if (totalCost <= B) {
            maxCrypto += dif;
            ++i;
        } else {
            // Daca banii nu ajung pentru a face un update complet
            // incerc sa fac un update cu mai putine unitati de
            // putere:
            --dif;
            while (dif > 0) {
                totalCost -= costuri[i];

                if (totalCost <= B) {
                    maxCrypto += dif;
                    break;
                }

                dif--;
            }
            break;
        }
    }

    return maxCrypto;
}

int main() {
    long N, B, i;
    long rez = 1;

    f1 >> N;
    f1 >> B;

    long *costuri = new long[N];

    // declararea vectorului de structuri de tip pereche:
    cryptoMoneda *perechi;
    perechi = new cryptoMoneda[N];

    for (i = 0; i < N; i++) {
        f1 >> perechi[i].P >> perechi[i].U;
    }

    // Sortarea vectorului de structuri:
    sort(perechi, perechi + N, comparator);

    // Calcularea costurilor necesare pentru upgrade-ul
    // tuturor calculatoarelor pana la un anumit indice:
    costuri[0] = perechi[0].U;
    for (i = 1; i < N; i++) {
        costuri[i] = costuri[i-1] + perechi[i].U;
    }

    // determinarea rezultatului final:
    rez = calculCostUpgrade(perechi, N, B, costuri);
    f2 << rez << endl;

    // eliberarea memoriei si inchiderea fisierelor:
    delete[] perechi;
    delete[] costuri;
    f2.close();
    f1.close();

    return 0;
}

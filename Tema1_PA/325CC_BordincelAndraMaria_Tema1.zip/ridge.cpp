#include <bits/stdc++.h>
#include <limits.h>

#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

fstream f1("ridge.in", ios::in),
        f2("ridge.out", ios::out);

struct munte {
    long long H;
    long long C;
};

long long calculCostMin(munte *perechi, long long dim) {
	long long i, j;

    vector<vector<long long>> dp(dim, vector<long long>(3));
    vector<long long> dif1(dim, 0);
    vector<long long> dif2(dim, 0);

    dp = {{0}};
    dp[0][1] = perechi[0].C;
    dp[0][2] = perechi[0].C * 2;

    // vectori de diferenta in care stochez diferenta
    // dintre elementul precedent - o unitate, respectiv
    // - 2 unitati:
    for (i = 1; i < dim; i++) {
        dif1[i] = perechi[i-1].H - 1;
        dif2[i] = perechi[i-1].H - 2;
    }

    for (i = 1; i < dim; i++) {
        for (j = 0; j < 3; j++) {
            long long minim = LLONG_MAX;

            // verific ca elementul curent sa ramana pozitiv
            // si caut minimul dintre el si cel de dinainte
            // pe aceeasi coloana:
            long long current = perechi[i].H - j;

            // verific sa nu fie egal cu cel precedent:
            if ((current >= 0) && (current != perechi[i-1].H)) {
                minim = min(minim, dp[i-1][0]);
            }

            // verific sa nu fie egal cu cel precedent - 1:
            if ((current >= 0) && (current != dif1[i])) {
                minim = min(minim, dp[i-1][1]);
            }

            // verific sa nu fie egal cu cel precedent - 2:
            if ((current >= 0) && (current != dif2[i])) {
                minim = min(minim, dp[i-1][2]);
            }

            // Daca minimul rezultat este diferit de limita
            // maxima determin valoarea curenta de sapaturi
            // necesare * costul lor + minimul pe care l-am
            // obtinut. Daca acesta nu este diferit de limita
            // setata, aceasta va fi valoarea necesara pentru
            // sapaturi:
            if (minim != LLONG_MAX) {
                dp[i][j] = j * perechi[i].C + minim;
            } else {
                dp[i][j] = minim;
            }
        }
    }

    // sortez crescator ultima linie a matricei de costuri de sapaturi:
    sort(dp[dim-1].begin(), dp[dim-1].end());

    // returnez cel mai mic element din aceasta, adica primul in urma
    // sortarii realizate:
    return dp[dim-1][0];
}

int main() {
    long long N;
    f1 >> N;
    long long i;


    munte *perechi;
    perechi = new munte[N];

    for (i = 0; i < N; i++) {
        f1 >> perechi[i].H >> perechi[i].C;
    }

	long long costMinim = 0;
	costMinim = calculCostMin(perechi, N);

    f2 << costMinim << endl;

	delete perechi;
	f2.close();
	f1.close();
	return 0;
}

#include <bits/stdc++.h>
#include <limits.h>
#include <iostream>
#include <fstream>

using namespace std;

fstream f1("valley.in", ios::in),
        f2("valley.out", ios::out);


using namespace std;

int main() {
    f2.close();
    f1.close();
    return 0;
}

#include <bits/stdc++.h>

#include <iostream>
#include <fstream>
#include <functional>
#include <algorithm>

using namespace std;

fstream f1("stocks.in", ios::in),
        f2("stocks.out", ios::out);


using namespace std;

struct actiuni {
    int currentValue;
    int minValue;
    int maxValue;
};

//  N = 100; B = 500; L = 100 -  valori maxime
// tablou tridimensional intiaizat cu 0 pe toate pozitiile:
int cost[101][501][101] = {{{0}}};

int calculProfitMaxim(actiuni *v, int N, int B, int L, int* w, int *b) {
    int i, j, k;

    for (i = 1; i <= N; i++) {
        for (j = 1; j <= B; j++) {
            for (k = 1; k <= L; k++) {
                // verific daca valoarea actuala se afla in buget si daca
                // diferenta intre aceasta si valoarea minima se afla in
                //  pierderea maxima:
                if ((v[i].currentValue <= j) && (w[i] <= k))
                    // calculez costul obtinut determinand maximul dintre
                    // diferenta dintre valoarea maxima si valoarea curenta,
                    // stocata in b[i], adunat cu costul precedent stocat in
                    // pasul i anterior, [i-1], valoarea bugetului ramas dupa
                    // sacaderea valorii curente din bugetul total pe pozitia j
                    // si valoarea profitului maxim obtinut din diferenta
                    // valorii maxime si a valorii curente pe pozitia k,
                    // si costul precedent:
                    cost[i][j][k] = max(b[i] +
                                        cost[i-1][j-v[i].currentValue]
                                        [k - w[i]], cost[i-1][j][k]);
                else
                    // daca conditia de mai sus nu este indeplinita, se va
                    // stoca costul precedent:
                    cost[i][j][k] = cost[i-1][j][k];
            }
        }
    }

    // rezultatul dorit se va afla in coltul din dreapta jos al tabloului
    // fiind ultimul element din acesta:
    return cost[N][B][L];
}

int main() {
    int N, B, L;
    int i;
    int rez;

    f1 >> N;  // nr de linii cu actiuni
    f1 >> B;  // banii lui gigel
    f1 >> L;  // pierderea maxima pe care o poate suporta


    actiuni *perechi;
    perechi = new actiuni[N+1];

    int *worst = new int[N+1];
    int *best = new int[N+1];

    for (i = 1; i <= N; i++) {
        f1 >> perechi[i].currentValue;
        f1 >> perechi[i].minValue;
        f1 >> perechi[i].maxValue;
    }


    // calculez diferentele dintre valoarea curenta si valoarea
    // minima, respectiv valoarea maxima si cea curenta:
    for (i = 1; i <= N; i++) {
        worst[i] = perechi[i].currentValue - perechi[i].minValue;
        best[i] = perechi[i].maxValue - perechi[i].currentValue;
    }

    rez = calculProfitMaxim(perechi, N, B, L, worst, best);
    f2 << rez << endl;

    delete[] best;
    delete[] worst;
    delete[] perechi;
    f2.close();
    f1.close();
    return 0;
}

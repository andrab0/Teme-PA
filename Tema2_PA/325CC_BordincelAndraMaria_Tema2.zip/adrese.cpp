#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

using namespace std;

fstream f1("adrese.in", ios::in),
		f2("adrese.out", ios::out);

int main() {
	return 0;
}

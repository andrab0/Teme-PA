#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

using namespace std;

fstream f1("retea.in", ios::in),
		f2("retea.out", ios::out);

int main() {
	return 0;
}

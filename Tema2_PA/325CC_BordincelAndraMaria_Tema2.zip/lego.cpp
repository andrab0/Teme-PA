#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

using namespace std;

/*	Deschiderea fisierelor pentru citire si scriere: */
fstream f1("lego.in", ios::in),
		f2("lego.out", ios::out);

/*	Functie pentru citirea datelor din fisier: */
void citireInput();
/*	Functie pentru calcularea combinarilor folosind metoda backtracking: */
void bkt(int nr);
/*	Functie pentru calcularea secventelor maxime consecutive: */
void coinPD();
/*	Functie pentru afisarea datelor obtinute in fisierul de iesire: */
void afisareOutput(int nrMax, const vector<int> &sol);

/*	date de intrare: */
int K, N, T;

/* date de iesire: */
int nrMax = -1;
vector<int> rezultat(11);

/*	date auxiliare:	*/
vector<int> solutii(11);


int main() {
	/*	Citirea datelor din fisier: */
	citireInput();

	//  Initializez primul element din combinare cu 1:
	solutii[1] = 1;
	//  Apelez functia de generare a combinarilor porind de la 2:
	bkt(2);

	/*	Afisarea datelor in fisierul de iesire: */
	afisareOutput(nrMax, rezultat);
	return 0;
}

void citireInput() {
	//  Citirea dimensiunii maxime a pieselor:
	f1 >> K;
	//  Citirea numarului de piese de baza:
	f1 >> N;
	//  Citirea numarului maxim de piese ce pot fi folosite:
	f1 >> T;

	//  Inchid fisierul de intrare:
	f1.close();
}

void afisareOutput(int nrMax, const vector<int> &sol) {
	int i;

	//  Afisez numarul maxim de dimensiuni consecutive in fisier:
	f2 << nrMax << endl;
	//  Afisez dimensiunile pieselor de baza:
	for (i = 1; i <= N; i++) {
		f2 << sol[i] << " ";
	}

	//  Inchid fisierul de iesire:
	f2.close();
}

void bkt(int nr) {
	int start = solutii[nr - 1] + 1;
	int i;

	//  Verific daca am aflat o combinare:
	if (nr > N) {
		//  Calculez numarul de secvente consecutive de piese de lego
		//  care se pot construii pentru combinarea curenta:
		coinPD();
	} else {
		//  Daca inca nu am aflat combinarea:
		for (i = start; i <= K; i++) {
			//  Completez urmatorul loc liber cu cifra aferenta:
			solutii[nr] = i;
			//  Reapelez constructia combinarii cu noua cifra pusa:
			bkt(nr + 1);
		}
	}
}

void coinPD() {
	int stop = solutii[N] * T;
	int i, j;
    //  Declar vectorul de secvente si il initializez in totalitate
	//  cu valori mari:
	vector<int> dp(1001, 99999);

	//  Declar contoarele pentru secventa maxima consecutiva si
	//  pentru cea curenta:
	int secventaMaxConsecutiva = 0,
		secventaCurenta = 0;

	//  Construiesc cazul de baza pentru 0 piese de unde imi
	//  va rezulta o secventa de lungime 0:
	dp[0] = 0;

	//  Calculez numarul de piese necesare pentru fiecare
	//  secventa pana la secventa maxima consecutiva inclusiv:
	for (i = 1; i <= stop; i++) {
		for (j = 1; j <= N ; j++) {
			if (solutii[j] <= i) {
				int temp = dp[i - solutii[j]] + 1;

				if(temp < dp[i]) {
					dp[i] = temp;
				}
			}
		}
	}

	//  Iterez prin secventele obtinute:
	for (i = 1; i <= stop; i++) {
		//  Verific daca am ajuns la finalul unei secvente:
		if ((dp[i] <= T)) {
			secventaCurenta++;
		} else {
			//  Vad daca e cea mai mare din combinarea respectiva:
			secventaMaxConsecutiva = max(secventaMaxConsecutiva, secventaCurenta);
			//  Vad daca e cea mai mare dintre toate combinarile obtinute
			//  pana in momentul actual:
			if(secventaCurenta > nrMax) {
				//  Daca este cea mai mare salvez acest numar si construiesc
				//  rezultatul:
				nrMax = secventaCurenta;
				for (j = 1; j <= N ; j++) {
					rezultat[j] = solutii[j];
				}
			}

			//  Reinitializez secventa curenta:
			secventaCurenta = 0;
		}

		//  Daca am terminat vectorul de secvente verific daca secventa
		// terminarii sirului este cea mai mare local si global:
		if (secventaCurenta > secventaMaxConsecutiva) {
			secventaMaxConsecutiva = secventaCurenta;
			if(secventaCurenta > nrMax) {
				nrMax = secventaCurenta;
				for (j = 1; j <= N ; j++) {
					rezultat[j] = solutii[j];
				}
			}
		}
	}
}

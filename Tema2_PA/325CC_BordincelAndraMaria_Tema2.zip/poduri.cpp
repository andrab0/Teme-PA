#include <bits/stdc++.h>
#include <iostream>
#include <fstream>

using namespace std;

fstream f1("poduri.in", ios::in),
		f2("poduri.out", ios::out);

int main() {
	return 0;
}

